# Thư mục giọng mẫu — bản cho phim

**Không commit file `.wav` thật lên GitHub public.** File `.gitignore` ở repo gốc đã chặn `voices/*.wav`.

## Mỗi nhân vật = 1 file mẫu riêng, không dùng chung

Đây là lỗi dễ mắc nhất khi làm phim: lấy cùng 1 giọng mẫu cho Sơn Tinh và Thủy Tinh thì 2 nhân vật sẽ nghe giống nhau, dù text khác nhau. Clone chỉ giữ lại chất giọng của file mẫu, nó không tự tạo ra 2 chất giọng khác nhau.

Thu riêng cho từng nhân vật trong `voices.json.example`:
- `son-tinh.wav` — trầm, chậm hơn một chút (trong CSV có thể đặt `speed` 0.95 cho vai này)
- `thuy-tinh.wav` — chất giọng khác hẳn Sơn Tinh, kể cả khi cùng 1 diễn viên đóng 2 vai thì cũng phải thu 2 buổi / 2 cách nói khác nhau, và ghi rõ đó là 2 vai diễn riêng
- `mi-nuong.wav`, `vua-hung.wav`, `lach.wav`, `nguoi-ke.wav`

Mỗi file kèm 1 file transcript cùng tên, đuôi `.txt`, khớp từng chữ.

## Yêu cầu file mẫu

- 1 người nói duy nhất, không nhạc, không ồn, không giọng khác chen vào
- 10–30 giây, đọc liền mạch, đúng chất giọng của nhân vật đó (đừng đọc giọng kể chuyện cho cả vai gầm lên lúc cao trào)
- `.wav`, mono, ≥ 16 kHz
- Giọng mẫu phải là giọng của chính bạn, hoặc của diễn viên đã đồng ý cho bạn dùng để lồng tiếng cho phim này. Giữ lại bằng chứng đồng ý đó, đừng chỉ nhớ miệng.

## Đặt tên output để ghép phim

Script đặt tên output theo `shot_id` trong CSV, ví dụ `outputs/C2-S01.wav`.
Giữ nguyên mã shot của storyboard (C1-S01… hoặc 01-01 theo bản storyboard bạn đang dùng), đừng đổi tên lung tung, nếu không lúc ghép vào animatic / timeline sẽ lệch thoại.
