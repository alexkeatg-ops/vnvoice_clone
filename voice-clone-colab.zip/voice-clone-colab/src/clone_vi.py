"""Lồng tiếng tiếng Việt bằng zalopay/vietnamese-tts (F5-TTS).

Hai cách dùng:

1. Một giọng duy nhất (test nhanh):
  python src/clone_vi.py --ref-audio voices/son-tinh.wav \
      --ref-text "transcript chính xác của file mẫu" \
      --csv examples/dialogue_example.csv --out-dir outputs

2. Nhiều nhân vật cho phim (khuyên dùng):
  python src/clone_vi.py --voices-map voices.json \
      --csv examples/dialogue_film_example.csv --out-dir outputs

File voices.json mẫu (xem voices.json.example):
  {
    "son-tinh": {"audio": "voices/son-tinh.wav", "transcript": "..."},
    "thuy-tinh": {"audio": "voices/thuy-tinh.wav", "transcript": "..."}
  }

CSV cho phim phải có cột: shot_id,character,text
  - shot_id: mã shot trong storyboard, vd C2-S03 hoặc 01-01.
    File output sẽ là outputs/<shot_id>.wav để ghép đúng timeline.
  - character: khóa trong voices.json, vd son-tinh, thuy-tinh, mi-nuong.
  - text: câu thoại. Câu dài sẽ tự tách thành từng câu ngắn rồi nối lại.

CSV một giọng (cách 1) dùng cột cũ: id,voice,text — cột voice lúc đó chỉ để
ghi chú, giọng thật lấy từ --ref-audio.
"""
import argparse
import csv
import json
import os
import re

import numpy as np
from scipy.io.wavfile import write as write_wav


def split_sentences(text):
    parts = re.split(r"(?<=[.!?…])\s+", text.strip())
    return [p for p in parts if p.strip()]


def load_model_and_vocoder():
    from f5_tts.infer.utils_infer import load_model, load_vocoder
    from f5_tts.model import DiT
    from huggingface_hub import hf_hub_download

    vocoder = load_vocoder()
    ckpt = hf_hub_download(repo_id="zalopay/vietnamese-tts", filename="model_960000.pt")
    vocab = hf_hub_download(repo_id="zalopay/vietnamese-tts", filename="vocab.txt")
    model = load_model(
        DiT,
        dict(dim=1024, depth=22, heads=16, ff_mult=2, text_dim=512, conv_layers=4),
        ckpt_path=ckpt,
        mel_spec_type="vocos",
        vocab_file=vocab,
    )
    return model, vocoder


def synth_one(model, vocoder, ref_audio, ref_text, text, nfe_step, speed):
    from f5_tts.infer.utils_infer import infer_process

    waves, sr = [], None
    for sent in split_sentences(text):
        wave, sr, _ = infer_process(
            ref_audio, ref_text, sent, model, vocoder,
            cross_fade_duration=0.15, nfe_step=nfe_step, speed=speed,
        )
        if hasattr(wave, "cpu"):
            wave = wave.cpu().numpy()
        waves.append(np.asarray(wave))
    return (np.concatenate(waves) if len(waves) > 1 else waves[0]), sr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ref-audio", help="Dùng cho cách 1 giọng duy nhất")
    ap.add_argument("--ref-text", help="Transcript chính xác của --ref-audio")
    ap.add_argument("--voices-map", help="File JSON map nhân vật -> giọng mẫu, dùng cho phim")
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out-dir", default="outputs")
    ap.add_argument("--nfe-step", type=int, default=32)
    ap.add_argument("--speed", type=float, default=1.0)
    args = ap.parse_args()

    if bool(args.voices_map) == bool(args.ref_audio):
        raise SystemExit("Chọn đúng 1 trong 2: --voices-map (nhiều nhân vật) hoặc --ref-audio + --ref-text (1 giọng).")

    from f5_tts.infer.utils_infer import preprocess_ref_audio_text

    model, vocoder = load_model_and_vocoder()
    os.makedirs(args.out_dir, exist_ok=True)

    # Cache giọng mẫu theo nhân vật: mỗi nhân vật preprocess 1 lần, không làm lại mỗi câu.
    refs = {}
    if args.voices_map:
        with open(args.voices_map, encoding="utf-8") as f:
            voice_map = json.load(f)
        for name, info in voice_map.items():
            refs[name] = preprocess_ref_audio_text(info["audio"], info["transcript"])
    else:
        refs["__single__"] = preprocess_ref_audio_text(args.ref_audio, args.ref_text)

    with open(args.csv, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    for row in rows:
        shot_id = row.get("shot_id") or row.get("id")
        character = row.get("character") or "__single__"
        if character not in refs:
            raise SystemExit(f"Nhân vật '{character}' ở shot {shot_id} không có trong voices-map. Kiểm tra lại CSV và voices.json.")
        ref_audio, ref_text = refs[character]
        speed = float(row.get("speed") or args.speed)
        wave, sr = synth_one(model, vocoder, ref_audio, ref_text, row["text"], args.nfe_step, speed)
        out_path = os.path.join(args.out_dir, f"{shot_id}.wav")
        write_wav(out_path, sr, wave)
        print(f"OK {shot_id} [{character}] -> {out_path}")


if __name__ == "__main__":
    main()
